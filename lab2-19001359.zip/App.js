import { StatusBar } from 'expo-status-bar';
import React, {useState, useEffect} from 'react';
import { StyleSheet, Text, View, ImageBackground, Picker, Button, } from 'react-native';

const fondo = { uri: "https://miro.medium.com/max/12000/1*rq4jPcm-qulPIVIjc8gjlw.jpeg" };


export default function App() {
  const [Moneda,setMoneda] = useState([]);
  const [cryptoMoneda, setCryptoMoneda] = useState(' ');
  const [cryptoMonedaPicker, setcryptoMonedaPicker] = useState([]);
  const [monedaNacional, setMonedaNacional] = useState('');
  const [Resultado, setResultado] = useState('');

  //promise para cargar las monedas
  let CryptoMonedasArray = [];
  useEffect(() => {
    fetch('https://min-api.cryptocompare.com/data/top/totalvolfull?limit=10&tsym=USD')
    .then(response => response.json())
    .then(data => {
      let CryptomonedaInfo = data.Data;
      CryptomonedaInfo.forEach(element => {
        CryptoMonedasArray.push(element.CoinInfo.Name);
      });
      setMoneda(CryptoMonedasArray);
    });
  }, []);

  let arrPickerItems = [];
  Moneda.map((item,index) =>{
    if(item != undefined){
      arrPickerItems.push(<Picker.Item label={item} value={item} key={index}/>)
    }
  });


  return (
    <ImageBackground source={fondo} style={styles.image}>
      <View style={styles.container}>

      
          {/*Titulo*/}
          <Text style={styles.titulo}>Conversión de Cryto-Moneda y Moneda Nacional  </Text>

            {/*Picker de monedas cryptomonedas*/}
            <View style={styles.pickers}>
              <Picker
                style={styles.cryptoMonedaPicker}
                selectedValue={cryptoMoneda}
                onValueChange={(itemValue, itemIndex) => {
                  setCryptoMoneda(itemValue)
                }}
        
              >
                {arrPickerItems}
              </Picker>

              {/*Picker de monedas nacionales*/}
              <Picker
                style={styles.monedaLocalPicker}
                selectedValue={monedaNacional}
                onValueChange={(itemValue, itemIndex) => {
                  setMonedaNacional(itemValue)
                }}
              >
                <Picker.Item label='USD' value='USD' />
                <Picker.Item label='GBP' value='GBP' />
                <Picker.Item label='EUR' value='EUR' />
                <Picker.Item label='JPY' value='JPY' />
              </Picker>
            </View>  

            <View style={[{ width: '40%', height: 40 , backgroundColor: "red", marginTop:100}]}>

              {/*Boton*/}
              <Button 
                color="red"
                title= "Convertir"
                onPress = {() => {
                  const URL = `https://min-api.cryptocompare.com/data/price?fsym=${cryptoMoneda}&tsyms=${monedaNacional }`;

                  let Resultado = ' ';

                  fetch(URL)
                    .then(response => response.json())
                    .then(datos =>{
                      Resultado = datos;
                      Resultado = JSON.stringify(datos)
                      Resultado = Resultado.slice(7,-1)
                      setResultado(Resultado)
                    })
                }}
              />
            </View>

        {cryptoMonedaPicker}
          
          {/*Resultado*/}
          <Text style={styles.respuesta}> Resultado: {Resultado} </Text>
      
      </View>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({

  container: {
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'Transparent'
  },

  image:{
    alignItems: 'center',
    justifyContent: 'center',
    resizeMode: "cover",
    flex:1
  },
  
  titulo:{
    fontSize: 15,
    fontFamily:'Goudy Stout',
    fontWeight: 'bold',
    marginBottom: 100,
    backgroundColor: 'white',
    borderWidth:20,
    borderLeftColor: 'white',
    borderRightColor:'white',
    bordercolor: 'white',
    color: '#569C93',
    padding: 20
  },

  pickers:{
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    width:'90%',
    marginTop: 40
  },

  cryptoMonedaPicker:{
    height: 50,
    width: '20%',
    backgroundColor: 'white',
    marginRight: 200,
    color:'black',
    fontSize:20,
    fontWeight: 'bold',
    paddingLeft:40,
    backgroundColor: '#F7EE62'

  },

  monedaLocalPicker:{
    height: 50,
    width: '20%',
    backgroundColor: 'white',
    color:'black',
    fontSize:20,
    fontWeight: 'bold',
    paddingLeft:40,
    backgroundColor: '#F7EE62'
  },

  respuesta: {
    marginTop: 100,
    fontSize: 30,
    fontFamily: 'Abadi',
    fontWeight: 'bold',
    borderRadius:10,
    color: '#000',
    backgroundColor: 'white',
    paddingRight:'20',
    paddingTop:'20',
    paddingBottom:'20',
    paddingLeft:'20',
  },
  

  
});